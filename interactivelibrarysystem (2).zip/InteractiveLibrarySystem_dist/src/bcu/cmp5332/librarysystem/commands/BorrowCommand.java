
package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.time.LocalDate;

/**
 * The {@code BorrowCommand} class represents a command to borrow a book by a patron.
 * It implements the {@link Command} interface.
 *
 * @author [Your Name]
 * @version [Library Version]
 */
public class BorrowCommand implements Command {

    /**
     * The ID of the patron who wants to borrow the book.
     */
    private final int patronId;

    /**
     * The ID of the book to be borrowed.
     */
    private final int bookId;

    /**
     * Creates a new instance of {@code BorrowCommand} with the specified patron ID and book ID.
     *
     * @param patronId the ID of the patron who wants to borrow the book
     * @param bookId   the ID of the book to be borrowed
     */
    public BorrowCommand(int patronId, int bookId) {
        this.patronId = patronId;
        this.bookId = bookId;
    }

    /**
     * Executes the borrow command by calling the {@code borrowBook} method on the provided library.
     *
     * @param library      the library on which the operation is performed
     * @param currentDate  the current date when the command is executed
     * @throws LibraryException if there is an issue executing the borrow command
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        library.borrowBook(patronId, bookId, currentDate);
    }
}

