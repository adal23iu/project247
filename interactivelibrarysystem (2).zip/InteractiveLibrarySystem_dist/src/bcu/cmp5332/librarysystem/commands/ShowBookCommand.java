
package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.time.LocalDate;

/**
 * Represents a command to display details of a book by its ID.
 * Implements the Command interface.
 */
public class ShowBookCommand implements Command {

    /** The ID of the book to be displayed. */
    private final int bookID;

    /**
     * Constructs a ShowBookCommand with the specified book ID.
     *
     * @param bookID The ID of the book to be displayed.
     */
    public ShowBookCommand(int bookID) {
        this.bookID = bookID;
    }

    /**
     * Executes the ShowBookCommand by retrieving the book from the library and
     * displaying its details on the console.
     *
     * @param library      The library containing the books.
     * @param currentDate  The current date for reference (not used in this command).
     * @throws LibraryException If an error occurs during the execution of the command.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        // Retrieve the book from the library using the provided book ID.
        Book book = library.getBookByID(bookID);

        // Display book details if the book is found; otherwise, print a message.
        if (book != null) {
            System.out.println("Book details:");
            System.out.println("ID: " + book.getId());
            System.out.println("Title: " + book.getTitle());
            System.out.println("Author: " + book.getAuthor());
            System.out.println("Publisher: " + book.getPublisher());
            System.out.println("Publication Year: " + book.getPublicationYear());
            System.out.println("Deleted: " + book.isDeleted());
            System.out.println("Available: " + book.isAvailable());
        } else {
            System.out.println("Book with ID " + bookID + " not found.");
        }
    }
}

