
package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.time.LocalDate;
import java.util.List;

/**
 * The {@code ListBooks} class implements the {@code Command} interface
 * to display a short summary of all books in the library.
 */
public class ListBooks implements Command {

    /**
     * Executes the command to list all books in the library along with their short details.
     * Prints the total number of books in the library.
     *
     * @param library      the {@code Library} instance
     * @param currentDate  the current date
     * @throws LibraryException if there is an issue accessing the library or printing details
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        List<Book> books = library.getBooks();
        for (Book book : books) {
            System.out.println(book.getDetailsShort());
        }
        System.out.println(books.size() + " book(s)");
    }
}
