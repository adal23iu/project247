
package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.time.LocalDate;

/**
 * Represents a command to return a book to the library.
 */
public class ReturnCommand implements Command {

    // Fields to store the patron ID and book ID for the return operation
    private final int patronId;
    private final int bookId;

    /**
     * Constructs a ReturnCommand with the specified patron ID and book ID.
     *
     * @param patronId The ID of the patron returning the book.
     * @param bookId   The ID of the book being returned.
     */
    public ReturnCommand(int patronId, int bookId) {
        this.patronId = patronId;
        this.bookId = bookId;
    }

    /**
     * Executes the return command on the given library with the specified current date.
     *
     * @param library      The library on which the return operation is performed.
     * @param currentDate  The current date for the return operation.
     * @throws LibraryException If an error occurs during the return operation.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        library.returnBook(patronId, bookId, currentDate);
    }
}
