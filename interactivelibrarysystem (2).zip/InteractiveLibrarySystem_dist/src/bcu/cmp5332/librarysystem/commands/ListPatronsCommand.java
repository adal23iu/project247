
package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.model.Patron;

import java.time.LocalDate;

/**
 * The ListPatronsCommand class implements the Command interface
 * to display a list of active patrons in the library.
 */
public class ListPatronsCommand implements Command {

    /**
     * Executes the ListPatronsCommand to display a list of active patrons.
     *
     * @param library      The library instance containing the list of patrons.
     * @param currentDate  The current date for reference (not used in this command).
     * @throws LibraryException If an error occurs while executing the command.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        for (Patron patron : library.getActivePatrons()) {
            System.out.println(patron);
        }
    }
}

