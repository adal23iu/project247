
package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.model.Patron;

import java.time.LocalDate;

/**
 * The {@code AddPatron} class represents a command to add a new patron to the library system.
 * It implements the {@link Command} interface.
 */
public class AddPatron implements Command {

    private final String name;
    private final String phone;
    private final String email;

    /**
     * Constructs a new {@code AddPatron} command with the specified patron details.
     *
     * @param name  The name of the patron.
     * @param phone The phone number of the patron.
     * @param email The email address of the patron.
     */
    public AddPatron(String name, String phone, String email) {
        this.name = name;
        this.phone = phone;
        this.email = email;
    }

    /**
     * Executes the {@code AddPatron} command, adding a new patron to the library.
     *
     * @param library     The {@link Library} instance representing the library system.
     * @param currentDate The current date used for library operations.
     * @throws LibraryException if a patron with the same name and phone number already exists.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        // Check if a patron with the same name and phone number already exists
        if (library.getPatronByNameAndPhone(name, phone) != null) {
            throw new LibraryException("Patron with the same name and phone number already exists.");
        }

        // Create a new Patron object with a temporary ID
        Patron patron = new Patron(-1, name, phone, email);

        // Use the addPatron method in the library, which will generate a unique ID for the new patron
        library.addPatron(patron);

        System.out.println("Patron added successfully with ID: " + patron.getId());
    }
}
