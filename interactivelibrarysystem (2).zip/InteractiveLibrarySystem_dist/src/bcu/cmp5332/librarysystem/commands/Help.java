
package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Library;

import java.time.LocalDate;

/**
 * The {@code Help} class represents a command to display the help message.
 * This command is used to provide assistance and information about available commands.
 *
 */
public class Help implements Command {

    /**
     * Executes the Help command, displaying the help message to the user.
     *
     * @param library      The Library object representing the library system.
     * @param currentDate  The current date when the command is executed.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) {
        System.out.println(Command.HELP_MESSAGE);
    }
}

 