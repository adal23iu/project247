
package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.time.LocalDate;

/**
 * Represents a command to show details of a patron in a library.
 * Implements the {@link Command} interface.
 */
public class ShowPatronCommand implements Command {

    /**
     * The ID of the patron for whom the details will be shown.
     */
    private final int patronId;

    /**
     * Constructs a new {@code ShowPatronCommand} with the specified patron ID.
     *
     * @param patronId The ID of the patron for whom the details will be shown.
     */
    public ShowPatronCommand(int patronId) {
        this.patronId = patronId;
    }

    /**
     * Executes the show patron details command on the given library.
     *
     * @param library      The library on which the command will be executed.
     * @param currentDate  The current date when the command is executed.
     * @throws LibraryException If an error occurs during the execution of the command.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        library.showPatronDetails(patronId);
    }
}
