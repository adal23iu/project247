
package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.time.LocalDate;

/**
 * The {@code RenewCommand} class represents a command to renew a book for a specific patron in the library system.
 * It implements the {@code Command} interface.
 */
public class RenewCommand implements Command {

    /**
     * The ID of the patron who wants to renew the book.
     */
    private final int patronId;

    /**
     * The ID of the book to be renewed.
     */
    private final int bookId;

    /**
     * Constructs a {@code RenewCommand} with the specified patron ID and book ID.
     *
     * @param patronId The ID of the patron who wants to renew the book.
     * @param bookId   The ID of the book to be renewed.
     */
    public RenewCommand(int patronId, int bookId) {
        this.patronId = patronId;
        this.bookId = bookId;
    }

    /**
     * Executes the renew command, attempting to renew the specified book for the given patron.
     *
     * @param library      The {@code Library} instance representing the library system.
     * @param currentDate  The current date when the command is executed.
     * @throws LibraryException If an error occurs while renewing the book.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        library.renewBook(patronId, bookId, currentDate);
    }
}
