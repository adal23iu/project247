
package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.gui.MainWindow;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;
import java.time.LocalDate;

/**
 * The {@code LoadGUI} class represents a command to load the graphical user interface (GUI) for the library system.
 * It implements the {@code Command} interface and is responsible for executing the GUI loading operation.
 */
public class LoadGUI implements Command {

    /**
     * Executes the command to load the GUI for the library system.
     *
     * @param library The {@code Library} object representing the library system.
     * @param currentDate The current date of the library system.
     * @throws LibraryException if there is an error during the execution of the command.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        new MainWindow(library);
    }
    
}
