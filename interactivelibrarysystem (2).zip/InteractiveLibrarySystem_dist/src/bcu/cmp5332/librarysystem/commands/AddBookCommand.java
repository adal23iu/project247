
package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.data.BookDataManager;

import java.io.IOException;
import java.time.LocalDate;


/**
 * Represents a command to add a new book to the library.
 * Implements the Command interface.
 */
public class AddBookCommand implements Command {

    private final int id;
    private final String title;
    private final String author;
    private final String publicationYear;
    private final String publisher;
    private final boolean deleted;
    private final boolean available;

    /**
     * Constructor for AddBookCommand.
     *
     * @param id               The unique identifier for the book.
     * @param title            The title of the book.
     * @param author           The author of the book.
     * @param publicationYear  The publication year of the book.
     * @param publisher        The publisher of the book.
     * @param deleted          A boolean indicating if the book is deleted or not.
     * @param available        A boolean indicating if the book is available for borrowing.
     */
    public AddBookCommand(int id, String title, String author, String publicationYear,
                          String publisher, boolean deleted, boolean available) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
        this.publisher = publisher;
        this.deleted = deleted;
        this.available = available;
    }

    /**
     * Executes the command by adding a new book to the library.
     *
     * @param library      The library instance where the book is added.
     * @param currentDate  The current date for loan due date calculation.
     */
    @Override
    public void execute(Library library, LocalDate currentDate) {
        try {
            // Create a new Book instance
            Book book = new Book(id, title, author, publicationYear, publisher, deleted, available);
            
            // Add the book to the library
            library.addBook(book);

            // Create an instance of BookDataManager
            BookDataManager bookDataManager = new BookDataManager();

            // Save books using BookDataManager
            bookDataManager.storeData(library);

            System.out.println("Book #" + book.getId() + " added.");
        } catch (IOException e) {
            // Handle IOException
            System.err.println("IOException: " + e.getMessage());
        }
    }
}
