
package bcu.cmp5332.librarysystem.data;

import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Handles data operations for books.
 */
public class BookDataManager implements BookDataManagerInterface {

    // Constants
    private static final String RESOURCE = "./resources/data/books.txt";
    private static final String SEPARATOR = ",";

    /**
     * Loads book data from a file into the provided library.
     *
     * @param library The Library instance to which the book data will be loaded.
     * @throws IOException       If an I/O error occurs while reading the file.
     * @throws LibraryException  If there is an issue with the library or data integrity.
     */
    @Override
    public void loadData(Library library) throws IOException, LibraryException {
        try (Scanner sc = new Scanner(new File(RESOURCE))) {
            int lineIdx = 1;
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] properties = line.split(SEPARATOR, -1);

                try {
                    int id = Integer.parseInt(properties[0]);
                    String title = properties[1];
                    String author = properties[2];
                    String publicationYear = properties[3];
                    String publisher = properties[4];

                    if (properties.length >= 7) {
                        boolean deleted = Boolean.parseBoolean(properties[5]);
                        boolean available = Boolean.parseBoolean(properties[6]);
                        Book book = new Book(id, title, author, publicationYear, publisher, deleted, available);
                        library.addBook(book);
                    } else {
                        System.err.println("Incomplete data on line " + lineIdx);
                    }
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException ex) {
                    throw new LibraryException("Error parsing book data on line " + lineIdx + "\nError: " + ex);
                }
                lineIdx++;
            }
        }
    }

    /**
     * Stores book data from the library into a file.
     *
     * @param library The Library instance from which book data will be stored.
     * @throws IOException If an I/O error occurs while writing to the file.
     */
    @Override
    public void storeData(Library library) throws IOException {
        try (PrintWriter out = new PrintWriter(new FileWriter(RESOURCE))) {
            for (Book book : library.getBooks()) {
                if (!book.isDeleted()) {
                    out.println(book.getId() + SEPARATOR +
                            book.getTitle() + SEPARATOR +
                            book.getAuthor() + SEPARATOR +
                            book.getPublicationYear() + SEPARATOR +
                            book.getPublisher() + SEPARATOR +
                            book.isDeleted() + SEPARATOR +
                            book.isAvailable());
                }
            }
        }
    }

    /**
     * Updates the details of an existing book.
     *
     * @param updatedBook The updated book.
     * @param library     The Library instance containing the books.
     * @throws LibraryException If the book is not found or is deleted.
     */
    public void updateBook(Book updatedBook, Library library) throws LibraryException {
        int bookId = updatedBook.getId();
        Book existingBook = library.getBookByID(bookId);

        if (existingBook == null) {
            throw new LibraryException("Book not found with ID: " + bookId);
        }

        if (!existingBook.isDeleted()) {
            existingBook.setTitle(updatedBook.getTitle());
            existingBook.setAuthor(updatedBook.getAuthor());
            existingBook.setPublicationYear(updatedBook.getPublicationYear());
            existingBook.setPublisher(updatedBook.getPublisher());
            System.out.println("Book updated successfully.");
        } else {
            throw new LibraryException("Cannot update a deleted book with ID: " + bookId);
        }
    }

    /**
     * Soft deletes a book by setting its 'isDeleted' property to true.
     *
     * @param bookId  The ID of the book to be deleted.
     * @param library The Library instance containing the books.
     * @throws LibraryException If the book with the given ID is not found.
     */
    public void softDeleteBook(int bookId, Library library) throws LibraryException {
        Book book = library.getBookByID(bookId);
        if (book == null) {
            throw new LibraryException("Book not found with ID: " + bookId);
        }
        book.setDeleted(true);
    }
}


    
