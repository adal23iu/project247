package bcu.cmp5332.librarysystem.data;

import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Library;

import java.io.IOException;

public interface BookDataManagerInterface extends DataManager {

	void storeData(Library library) throws IOException, LibraryException;
}