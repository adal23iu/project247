
package bcu.cmp5332.librarysystem.data;

import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.model.Patron;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.io.*;
import java.util.List;

/**
 * The PatronDataManager class manages the loading and storing of patron data for the library.
 * It implements the PatronDataManagerInterface and provides CRUD operations for patrons.
 */

public class PatronDataManager implements PatronDataManagerInterface {

	 // File path for storing patron data
    private static final String RESOURCE = "./resources/data/patrons.txt";
    // Separator used in the data file
    private static final String SEPARATOR = ",";

    /**
     * Loads patron data from the specified resource file into the library.
     *
     * @param library The library to which the patron data is loaded.
     * @throws IOException       If an I/O error occurs while reading the data file.
     * @throws LibraryException  If there is an issue with the data format or parsing.
     */
    
    @Override
    public void loadData(Library library) throws IOException, LibraryException {
        try (BufferedReader reader = new BufferedReader(new FileReader(RESOURCE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                try {
                    String[] parts = line.split(SEPARATOR);
                    if (parts.length != 4) {
                        throw new LibraryException("Invalid data format for creating Patron");
                    }

                    int id = Integer.parseInt(parts[0]);
                    String name = parts[1];
                    String phone = parts[2];
                    String email = parts[3];

                    Patron patron = new Patron(id, name, phone, email);
                    library.addPatronObject(patron);
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    throw new LibraryException("Error parsing patron data: " + e.getMessage());
                }
            }
        }
    }
    
    /**
     * Stores patron data from the library into the specified resource file.
     *
     * @param library The library from which patron data is stored.
     * @throws IOException If an I/O error occurs while writing to the data file.
     */

    @Override
    public void storeData(Library library) throws IOException {
        List<Patron> patrons = library.getAllPatrons();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(RESOURCE))) {
            for (Patron patron : patrons) {
                String line = String.format("%d,%s,%s,%s,%s",
                        patron.getId(),
                        patron.getName(),
                        patron.getPhone(),
                        patron.getEmail(),
                        SEPARATOR);

                writer.write(line);
                writer.newLine();
            }
        }
    }
    
    // CRUD operations for Patron
    /**
     * Creates a new patron and adds it to the library. Then, stores the updated data.
     *
     * @param library The library to which the new patron is added.
     * @param name    The name of the new patron.
     * @param phone   The phone number of the new patron.
     * @param email   The email address of the new patron.
     * @throws IOException       If an I/O error occurs while updating the data file.
     * @throws LibraryException  If there is an issue with adding the patron to the library.
     */

    public void createPatron(Library library, String name, String phone, String email) throws IOException, LibraryException {
        Patron patron = new Patron(name, phone, email); // Using the correct constructor
        try {
            library.addPatron(patron);
            storeData(library);
        } catch (LibraryException e) {
            e.printStackTrace();
        }
    }

    public Patron getPatronByID(Library library, int patronID) throws LibraryException {
        Patron patron = library.getPatronByID(patronID);
        if (patron == null) {
            System.out.println("Patron with ID " + patronID + " not found in the library.");
        }
        return patron;
    }

    public void updatePatron(Library library, Patron updatedPatron) {
        try {
            library.updatePatron(updatedPatron);
            storeData(library);
        } catch (IOException | LibraryException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void deletePatron(Library library, int patronId) throws IOException, LibraryException {
        try {
            Patron patron = library.getPatronByID(patronId);
            if (patron == null) {
                throw new LibraryException("Patron not found with ID: " + patronId);
            }

            // Soft delete the patron by setting the 'isDeleted' property to true
            patron.setDeleted(true);

            storeData(library);
        } catch (LibraryException e) {
            throw new IOException("Failed to delete patron: " + e.getMessage());
        }
    }
    
    public void listAllPatrons(Library library) {
        for (Patron patron : library.getActivePatrons()) {
            System.out.println(patron);
        }
    }
    
    /**
     * Adds a patron to the library and stores the updated data.
     *
     * @param library The library to which the patron is added.
     * @param patron  The patron to be added.
     * @throws IOException       If an I/O error occurs while updating the data file.
     * @throws LibraryException  If there is an issue with adding the patron to the library.
     */

    // PatronDataManager class
    public void addPatron(Library library, Patron patron) throws IOException {
        try {
            library.addPatronObject(patron);
            storeData(library);
        } catch (LibraryException e) {
            // Handle the LibraryException or log it as needed
            e.printStackTrace();
        }
    }
    
    /**
     * Stores the patron data from the library. This method is mainly provided for consistency
     * with the interface and can be used to explicitly trigger data storage.
     *
     * @param library The library from which patron data is stored.
     * @throws IOException       If an I/O error occurs while updating the data file.
     * @throws LibraryException  If there is an issue with storing the patron data.
     */

    public void storePatronData(Library library) throws IOException, LibraryException {
        storeData(library);
    }
}


