
package bcu.cmp5332.librarysystem.data;

import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * The {@code LibraryData} class manages the loading and storing of data for a library.
 * It utilises various {@link DataManager} implementations to handle different types of data.
 */
public class LibraryData {

    // The list of data managers responsible for handling different types of data
    private static final List<DataManager> dataManagers = new ArrayList<>();

    // Static block to initialize the data managers when the class is loaded into memory
    static {
        dataManagers.add(new BookDataManager());
        dataManagers.add(new PatronDataManager());
        dataManagers.add(new LoanDataManager());
    }

    /**
     * Loads data from various data managers into a {@link Library} object.
     *
     * @return The {@code Library} object containing loaded data.
     * @throws LibraryException If an exception related to the library occurs during loading.
     * @throws IOException     If an I/O exception occurs during loading.
     */
    public static Library load() throws LibraryException, IOException {
        Library library = new Library();
        for (DataManager dm : dataManagers) {
            dm.loadData(library);
        }
        return library;
    }

    /**
     * Stores data from a {@link Library} object using various data managers.
     *
     * @param library The {@code Library} object containing data to be stored.
     * @throws IOException     If an I/O exception occurs during storing.
     * @throws LibraryException If an exception related to the library occurs during storing.
     */
    public static void store(Library library) throws IOException, LibraryException {
        for (DataManager dm : dataManagers) {
            dm.storeData(library);
        }
    }
}
