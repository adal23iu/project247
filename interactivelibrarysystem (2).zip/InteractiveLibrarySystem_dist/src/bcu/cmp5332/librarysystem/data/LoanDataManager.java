package bcu.cmp5332.librarysystem.data;

import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.model.Loan;
import bcu.cmp5332.librarysystem.model.Patron;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

/**
 * The {@code LoanDataManager} class implements the {@code LoanDataManagerInterface},
 * providing methods to load and store loan data in a library from/to a text file.
 */
public class LoanDataManager implements LoanDataManagerInterface {

    /** The file path for the loans data resource. */
    private final String RESOURCE = "./resources/data/loans.txt";

    /**
     * Constructs a new {@code LoanDataManager} object.
     */
    public LoanDataManager() {
    }

    /**
     * Loads loan data from the specified file into the given library.
     *
     * @param library The library to which the loan data will be loaded.
     * @throws IOException       If an I/O error occurs while reading the file.
     * @throws LibraryException  If there is an issue with the library or the loan data.
     */
    @Override
    public void loadData(Library library) throws IOException, LibraryException {
        try (BufferedReader reader = new BufferedReader(new FileReader(RESOURCE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                try {
                    String[] parts = line.split(",");
                    int id = Integer.parseInt(parts[0]);
                    int bookId = Integer.parseInt(parts[1]);
                    int patronId = Integer.parseInt(parts[2]);
                    LocalDate startDate = parseDate(parts[3]);
                    LocalDate dueDate = parseDate(parts[4]);
                    boolean terminated = Boolean.parseBoolean(parts[5]);              

                    Patron patron = library.getPatronByID(patronId);
                    if (patron == null) {
                        throw new LibraryException("Patron with ID " + patronId + " not found in the library.");
                    }

                    Book book = library.getBookByID(bookId);
                    if (book == null) {
                        throw new LibraryException("There is no such book with ID " + bookId + ".");
                    }

                    Loan loan = new Loan(patron, book, startDate, dueDate);
                    loan.setId(id);
                    loan.setTerminated(terminated);
                    library.addLoan(loan);

                    // Update Patron's borrowed books list when loading loan data
                    patron.addBook(book);
                } catch (NumberFormatException | DateTimeParseException e) {
                    throw new LibraryException("Error parsing loan data: " + e.getMessage());
                }
            }
        }
    }

    /**
     * Stores loan data from the library into the specified file.
     *
     * @param library The library from which loan data will be stored.
     * @throws IOException If an I/O error occurs while writing to the file.
     */
    @Override
    public void storeData(Library library) throws IOException {
        List<Loan> loans = library.getAllLoans();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(RESOURCE))) {
            for (Loan loan : loans) {
                String returnDateStr = (loan.getReturnDate() != null) ? loan.getReturnDate().toString() : "";

                String line = String.format("%d,%d,%d,%s,%s,%b,%s",
                        loan.getId(),
                        loan.getBook().getId(),
                        loan.getPatron().getId(),
                        loan.getStartDate(),
                        loan.getDueDate(),
                        loan.isTerminated(),
                        returnDateStr
                );

                writer.write(line);
                writer.newLine();
            }
        }
    }

    /**
     * Parses a date from the given string representation.
     *
     * @param dateString The string representation of the date.
     * @return The parsed LocalDate, or null if the input is null or empty.
     */
    private LocalDate parseDate(String dateString) {
        if (dateString == null || dateString.trim().isEmpty() || dateString.equalsIgnoreCase("null")) {
            return null;
        }
        return LocalDate.parse(dateString);
    }
}
