
package bcu.cmp5332.librarysystem.main;

import bcu.cmp5332.librarysystem.data.LibraryData;
import bcu.cmp5332.librarysystem.commands.Command;
import bcu.cmp5332.librarysystem.model.Library;

import java.io.*;
import java.time.LocalDate;

/**
 * The Main class serves as the entry point for the Library System application.
 */
public class Main {

    /**
     * The main method of the application that initializes the library, processes user input,
     * and manages the overall execution of the Library System.
     *
     * @param args The command-line arguments (not used in this application).
     * @throws IOException        If an I/O error occurs while reading user input.
     * @throws LibraryException   If there is an issue with the library operations.
     */
    public static void main(String[] args) throws IOException, LibraryException {

        // Load library data from storage
        Library library = LibraryData.load();

        // Setup input reader
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        // Display initial message
        System.out.println("Library system");
        System.out.println("Enter 'help' to see a list of available commands.");

        // Main command processing loop
        while (true) {
            System.out.print("> ");
            String line = br.readLine();

            // Exit the loop if the user enters 'exit'
            if (line.equals("exit")) {
                break;
            }

            // Attempt to parse and execute the user command
            try {
                Command command = CommandParser.parse(line);
                command.execute(library, LocalDate.now());
            } catch (LibraryException ex) {
                // Display any library-related exceptions
                System.out.println(ex.getMessage());
            }
        }

        // Save library data before exiting
        LibraryData.store(library);

        // Terminate the application
        System.exit(0);
    }
}
 