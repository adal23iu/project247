
package bcu.cmp5332.librarysystem.main;

import bcu.cmp5332.librarysystem.commands.*;
import java.io.IOException;

import bcu.cmp5332.librarysystem.commands.ListBooks;
import bcu.cmp5332.librarysystem.commands.RenewCommand;
import bcu.cmp5332.librarysystem.commands.ReturnCommand;


/**
 * The CommandParser class is responsible for parsing user input and creating corresponding Command objects.
 * Supported commands include adding books and patrons, displaying book and patron information,
 * loading the graphical user interface (GUI), listing books and patrons, providing help,
 * as well as handling borrowing, renewing, and returning books.
 */
public class CommandParser {

    /**
     * Parses the input line and returns the corresponding Command object.
     *
     * @param line The input line to be parsed.
     * @return A Command object representing the parsed input.
     * @throws IOException      If an I/O error occurs.
     * @throws LibraryException If the input is invalid or cannot be parsed.
     */
    public static Command parse(String line) throws IOException, LibraryException {
        String[] parts = line.split(",");
        String cmd = parts[0];

        switch (cmd) {
            case "addbook":
                return parseAddBook(parts);
            case "showbook":
                return parseShowBook(parts);
            case "addpatron":
                return parseAddPatron(parts);
            case "showpatron":
                return parseShowPatron(parts);
            case "loadgui":
                return new LoadGUI();
            case "listbooks":
                return new ListBooks();
            case "listpatrons":
                return new ListPatronsCommand();
            case "help":
                return new Help();
            case "borrow":
                return parseBorrow(parts);
            case "renew":
                return parseRenew(parts);
            case "return":
                return parseReturn(parts);
            default:
                throw new LibraryException("Invalid command.");
        }
    }

    private static Command parseAddBook(String[] parts) throws LibraryException {
        if (parts.length < 8) {
            throw new LibraryException("Invalid command. Usage: addbook,[ID],[Title],[Author],[Publisher],[PublicationYear],[Deleted],[Available]");
        }

        try {
            // Extract the command arguments
            int id = Integer.parseInt(parts[1].trim());
            String title = parts[2].trim();
            String author = parts[3].trim();
            String publisher = parts[4].trim();
            String publicationYear = parts[5].trim();
            boolean deleted = Boolean.parseBoolean(parts[6].trim());
            boolean available = Boolean.parseBoolean(parts[7].trim());

            // Create and return the AddBookCommand with the parsed values
            return new AddBookCommand(id, title, author, publicationYear, publisher, deleted, available);
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException ex) {
            throw new LibraryException("Error parsing book data.\nError: " + ex);
        }
    }


    private static Command parseShowBook(String[] parts) throws LibraryException {
        if (parts.length < 2 || !parts[1].matches("\\d+")) {
            throw new LibraryException("Invalid command. Usage: showbook [bookID]");
        }
        int bookID = Integer.parseInt(parts[1]);
        return new ShowBookCommand(bookID);
    }

    private static Command parseAddPatron(String[] parts) throws LibraryException {
        if (parts.length < 4 || parts.length > 5) {
            throw new LibraryException("Invalid command. Usage: addpatron [name] [phone] [email]");
        }
        String name = parts[1].trim();
        String phone = parts[2].trim();
        String email = parts.length == 5 ? parts[3].trim() : null;
        return new AddPatron(name, phone, email);
    }

    private static Command parseShowPatron(String[] parts) throws LibraryException {
        if (parts.length < 2 || !parts[1].matches("\\d+")) {
            throw new LibraryException("Invalid command. Usage: showpatron [patronID]");
        }
        int patronID = Integer.parseInt(parts[1]);
        return new ShowPatronCommand(patronID);
    }

    private static Command parseBorrow(String[] parts) throws LibraryException {
        if (parts.length < 3 || !parts[1].matches("\\d+") || !parts[2].matches("\\d+")) {
            throw new LibraryException("Invalid command. Usage: borrow [patronID] [bookID]");
        }
        int patronID = Integer.parseInt(parts[1]);
        int bookID = Integer.parseInt(parts[2]);
        return new BorrowCommand(patronID, bookID);
    }

    private static Command parseRenew(String[] parts) throws LibraryException {
        if (parts.length < 3 || !parts[1].matches("\\d+") || !parts[2].matches("\\d+")) {
            throw new LibraryException("Invalid command. Usage: renew [patronID] [bookID]");
        }
        int patronID = Integer.parseInt(parts[1]);
        int bookID = Integer.parseInt(parts[2]);
        return new RenewCommand(patronID, bookID);
    }

    private static Command parseReturn(String[] parts) throws LibraryException {
        if (parts.length < 3 || !parts[1].matches("\\d+") || !parts[2].matches("\\d+")) {
            throw new LibraryException("Invalid command. Usage: return [patronID] [bookID]");
        }
        int patronID = Integer.parseInt(parts[1]);
        int bookID = Integer.parseInt(parts[2]);
        return new ReturnCommand(patronID, bookID);
    }
}

