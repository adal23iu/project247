
package bcu.cmp5332.librarysystem.gui;

import bcu.cmp5332.librarysystem.data.LibraryData;
import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.model.Patron;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

/**
 * The main window of the Library Management System application.
 * This class extends JFrame and implements ActionListener and Serializable.
 */
public class MainWindow extends JFrame implements ActionListener, Serializable {

    private static final long serialVersionUID = 1L;

    private JMenuBar menuBar;
    private JMenu adminMenu;
    private JMenu booksMenu;
    private JMenu membersMenu;

    private JMenuItem adminExit;
    private JMenuItem booksView;
    private JMenuItem booksAdd;
    private JMenuItem booksDel;
    private JMenuItem booksIssue;
    private JMenuItem booksReturn;
    private JMenuItem memView;
    private JMenuItem memAdd;
    private JMenuItem memDel;

    private Library library;
    private AddBookWindow addBookWindow;

    /**
     * Constructs a new MainWindow with the specified Library.
     *
     * @param library The Library to associate with the main window.
     */
    public MainWindow(Library library) {
        this.library = library;
        this.addBookWindow = new AddBookWindow(this);
        initialize();
    }

    /**
     * Retrieves the associated Library.
     *
     * @return The Library associated with the main window.
     */
    public Library getLibrary() {
        return library;
    }

    private void initialize() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        setTitle("Library Management System");

        menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        adminMenu = new JMenu("Admin");
        menuBar.add(adminMenu);

        adminExit = new JMenuItem("Exit");
        adminMenu.add(adminExit);
        adminExit.addActionListener(this);

        booksMenu = new JMenu("Books");
        menuBar.add(booksMenu);

        booksView = new JMenuItem("View");
        booksAdd = new JMenuItem("Add");
        booksDel = new JMenuItem("Delete");
        booksIssue = new JMenuItem("Issue");
        booksReturn = new JMenuItem("Return");
        booksMenu.add(booksView);
        booksMenu.add(booksAdd);
        booksMenu.add(booksDel);
        booksMenu.add(booksIssue);
        booksMenu.add(booksReturn);
        for (int i = 0; i < booksMenu.getItemCount(); i++) {
            booksMenu.getItem(i).addActionListener(this);
        }

        membersMenu = new JMenu("Members");
        menuBar.add(membersMenu);

        memView = new JMenuItem("View");
        memAdd = new JMenuItem("Add");
        memDel = new JMenuItem("Delete");

        membersMenu.add(memView);
        membersMenu.add(memAdd);
        membersMenu.add(memDel);

        memView.addActionListener(this);
        memAdd.addActionListener(this);
        memDel.addActionListener(this);

        setSize(800, 500);
        setVisible(true);
        setAutoRequestFocus(true);
        toFront();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    /**
     * The main method to launch the Library Management System application.
     *
     * @param args The command line arguments.
     */
    public static void main(String[] args) {
        try {
            Library library = LibraryData.load();
            new MainWindow(library);
        } catch (IOException | LibraryException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == adminExit) {
            System.exit(0);
        } else if (ae.getSource() == booksView) {
            displayBooks();
        } else if (ae.getSource() == booksAdd) {
            addBookWindow.setVisible(true);
        } else if (ae.getSource() == booksDel) {
            deleteBook();
        } else if (ae.getSource() == booksIssue) {
            issueBook();
        } else if (ae.getSource() == booksReturn) {
            returnBook();
        } else if (ae.getSource() == memView) {
            displayPatrons();
        } else if (ae.getSource() == memAdd) {
            addPatron();
        } else if (ae.getSource() == memDel) {
            deletePatron();
        }
    }

    private void displayBooks() {
        List<Book> booksList = library.getBooks();
        String[] columns = new String[]{"ID", "Title", "Author", "Pub Date", "Publisher", "Status"};

        Object[][] data = new Object[booksList.size()][6];
        for (int i = 0; i < booksList.size(); i++) {
            Book book = booksList.get(i);
            data[i][0] = book.getId();
            data[i][1] = book.getTitle();
            data[i][2] = book.getAuthor();
            data[i][3] = book.getPublicationYear();
            data[i][4] = book.getPublisher();
            data[i][5] = book.getStatus();
        }

        JTable table = new JTable(new DefaultTableModel(data, columns));
        updateTable(table);
    }

    private void updateTable(JTable table) {
        this.getContentPane().removeAll();
        this.getContentPane().add(new JScrollPane(table));
        this.revalidate();
    }

    private void deleteBook() {
        try {
            String bookIdStr = JOptionPane.showInputDialog(this, "Enter the Book ID to delete:");
            if (bookIdStr == null || bookIdStr.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Invalid Book ID entered!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int bookId = Integer.parseInt(bookIdStr);
            library.removeBook(bookId);

            JOptionPane.showMessageDialog(this, "Book deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid Book ID!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error deleting the book: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void issueBook() {
        try {
            String bookIdStr = JOptionPane.showInputDialog(this, "Enter the Book ID to issue:");
            String patronIdStr = JOptionPane.showInputDialog(this, "Enter the Patron ID:");

            if (bookIdStr == null || patronIdStr == null || bookIdStr.trim().isEmpty() || patronIdStr.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Invalid Book ID or Patron ID entered!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int bookId = Integer.parseInt(bookIdStr);
            int patronId = Integer.parseInt(patronIdStr);

            library.issueBook(bookId, patronId);

            JOptionPane.showMessageDialog(this, "Book issued successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid Book ID and Patron ID!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error issuing the book: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void returnBook() {
        try {
            String bookIdStr = JOptionPane.showInputDialog(this, "Enter the Book ID to return:");
            String patronIdStr = JOptionPane.showInputDialog(this, "Enter the Patron ID:");

            if (bookIdStr == null || patronIdStr == null || bookIdStr.trim().isEmpty() || patronIdStr.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Invalid Book ID or Patron ID entered!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int bookId = Integer.parseInt(bookIdStr);
            int patronId = Integer.parseInt(patronIdStr);

            library.returnBook(bookId, patronId, LocalDate.now());

            JOptionPane.showMessageDialog(this, "Book returned successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid Book ID and Patron ID!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error returning the book: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void displayPatrons() {
        List<Patron> patronsList = new ArrayList<>(library.getPatrons().values());
        String[] columns = new String[]{"ID", "Name", "Phone", "Email", "Deleted"};

        Object[][] data = new Object[patronsList.size()][5];

        for (int i = 0; i < patronsList.size(); i++) {
            Patron patron = patronsList.get(i);
            data[i][0] = patron.getId();
            data[i][1] = patron.getName();
            data[i][2] = patron.getPhone();
            data[i][3] = patron.getEmail();
            data[i][4] = patron.isDeleted();
        }

        JTable table = new JTable(new DefaultTableModel(data, columns));

        // Add the table to a JScrollPane to enable scrolling
        JScrollPane scrollPane = new JScrollPane(table);

        // Add the JScrollPane to the content pane
        this.getContentPane().removeAll();
        this.getContentPane().add(scrollPane);
        this.revalidate();
    }

    private void addPatron() {
        try {
            String name = JOptionPane.showInputDialog(this, "Enter the patron name:");
            String phone = JOptionPane.showInputDialog(this, "Enter the patron phone:");
            String email = JOptionPane.showInputDialog(this, "Enter the patron email:");

            // Create a new Patron object with the next available ID
            Patron newPatron = new Patron(name, phone, email);

            // Add the patron to the library using the addPatronObject method
            library.addPatronObject(newPatron);

            // Display updated list of patrons
            displayPatrons();

            JOptionPane.showMessageDialog(this, "Patron added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (LibraryException e) {
            JOptionPane.showMessageDialog(this, "Error adding the patron: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            // Handle any other exceptions that might occur
            JOptionPane.showMessageDialog(this, "Unexpected error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void deletePatron() {
        try {
            String patronIdStr = JOptionPane.showInputDialog(this, "Enter the Patron ID to delete:");
            if (patronIdStr == null || patronIdStr.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Invalid Patron ID entered!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int patronId = Integer.parseInt(patronIdStr);
            library.deletePatron(patronId);

            JOptionPane.showMessageDialog(this, "Patron deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid Patron ID!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (LibraryException e) {
            JOptionPane.showMessageDialog(this, "Error deleting the patron: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

