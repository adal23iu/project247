
package bcu.cmp5332.librarysystem.gui;

import bcu.cmp5332.librarysystem.commands.AddBookCommand;
import bcu.cmp5332.librarysystem.commands.Command;
import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Book;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.List;

/**
 * The AddBookWindow class represents the GUI window for adding a new book to the library.
 */
public class AddBookWindow extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    private MainWindow mw;
    private JList<String> bookList;  // Add JList to display books

    private JTextField titleText = new JTextField();
    private JTextField authText = new JTextField();
    private JTextField pubDateText = new JTextField();
    private JTextField publisherText = new JTextField();

    private JButton addBtn = new JButton("Add");
    private JButton cancelBtn = new JButton("Cancel");

    /**
     * Constructs an AddBookWindow object.
     *
     * @param mw The MainWindow instance.
     */
    public AddBookWindow(MainWindow mw) {
        this.mw = mw;
        initialize();
    }

    /**
     * Initialises the AddBookWindow by setting up its components and layout.
     */
    private void initialize() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        setTitle("Add a New Book");
        setSize(300, 200);

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(5, 2));
        topPanel.add(new JLabel("Title : "));
        topPanel.add(titleText);
        topPanel.add(new JLabel("Author : "));
        topPanel.add(authText);
        topPanel.add(new JLabel("Publishing Date : "));
        topPanel.add(pubDateText);
        topPanel.add(new JLabel("Publisher : "));
        topPanel.add(publisherText);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new GridLayout(1, 3));
        bottomPanel.add(new JLabel("     "));
        bottomPanel.add(addBtn);
        bottomPanel.add(cancelBtn);

        addBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        this.getContentPane().add(topPanel, BorderLayout.CENTER);
        this.getContentPane().add(bottomPanel, BorderLayout.SOUTH);
        setLocationRelativeTo(mw);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == addBtn) {
            addBook();
        } else if (ae.getSource() == cancelBtn) {
            clearInputFields();
            this.setVisible(false);
        }
    }

    /**
     * Adds a new book to the library based on user input.
     */
    private void addBook() {
        try {
            String title = titleText.getText();
            String author = authText.getText();
            String publicationYear = pubDateText.getText();
            String publisher = publisherText.getText();

            try {
                Integer.parseInt(publicationYear);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid publication year. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int id = generateUniqueBookId(); 
            boolean deleted = false; // Assume initially not deleted
            boolean available = true; // Assume initially available

            Command addBookCommand = new AddBookCommand(id, title, author, publicationYear, publisher, deleted, available);
            addBookCommand.execute(mw.getLibrary(), LocalDate.now());

            // Refresh the view with the list of books
            updateBooksList();

            // Hide (close) the AddBookWindow
            this.setVisible(false);
        } catch (LibraryException ex) {
            JOptionPane.showMessageDialog(this, ex, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Generates a unique book ID based on the current timestamp.
     *
     * @return The generated unique book ID.
     */
    private int generateUniqueBookId() {
        return (int) System.currentTimeMillis();
    }

    /**
     * Updates the JList displaying the list of books in the main window.
     */
    private void updateBooksList() {
        DefaultListModel<String> listModel = new DefaultListModel<>();

        List<Book> books = mw.getLibrary().getBooks();

        for (Book book : books) {
            String bookDetails = String.format("Book #%d - %s by %s", book.getId(), book.getTitle(), book.getAuthor());
            listModel.addElement(bookDetails);
        }

        // Set the updated listModel to your JList
        bookList.setModel(listModel);

        // Refresh your GUI or perform any other necessary updates
        mw.repaint();
    }

    /**
     * Clears the input fields in the AddBookWindow.
     */
    private void clearInputFields() {
        titleText.setText("");
        authText.setText("");
        pubDateText.setText("");
        publisherText.setText("");
    }
}

