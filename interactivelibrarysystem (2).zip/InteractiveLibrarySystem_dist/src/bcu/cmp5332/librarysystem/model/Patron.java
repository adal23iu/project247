package bcu.cmp5332.librarysystem.model;

import bcu.cmp5332.librarysystem.main.LibraryException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * The Patron class represents a library patron with basic details and a list of borrowed books.
 */
public class Patron {

    private static final int MAX_BOOKS_ALLOWED = 5;
    private static int patronCounter = 1;

    private int id; // Unique identifier for the patron
    private String name; // Name of the patron
    private String phone; // Phone number of the patron
    private String email; // Email address of the patron
    private boolean deleted; // Indicates if the patron is deleted or not
    private final List<Book> books = new ArrayList<>(); // List of borrowed books

    /**
     * Constructs a new Patron object with the specified details.
     *
     * @param id    The unique identifier for the patron.
     * @param name  The name of the patron.
     * @param phone The phone number of the patron.
     * @param email The email address of the patron.
     */
    public Patron(int id, String name, String phone, String email) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.deleted = false;
    }

    /**
     * Constructs a new Patron object with a generated unique identifier and the specified details.
     *
     * @param name  The name of the patron.
     * @param phone The phone number of the patron.
     * @param email The email address of the patron.
     */
    public Patron(String name, String phone, String email) {
        this(generateUniqueId(), name, phone, email);
    }

    /**
     * Borrow a book for the patron with a specified due date.
     *
     * @param book    The book to be borrowed.
     * @param dueDate The due date for returning the book.
     * @throws LibraryException If the patron already has borrowed the book or if the book is not available for borrowing.
     */
    public void borrowBook(Book book, LocalDate dueDate) throws LibraryException {
        if (books.contains(book)) {
            throw new LibraryException("Patron already has borrowed this book.");
        }
        if (!book.isAvailable()) {
            throw new LibraryException("Book is not available for borrowing.");
        }
        book.setDueDate(dueDate);
        book.setLoan(new Loan(this, book, LocalDate.now(), dueDate));
        book.setAvailable(false);
        books.add(book);
    }

    /**
     * Renew the due date for a borrowed book.
     *
     * @param book    The book to be renewed.
     * @param dueDate The new due date for the book.
     * @throws LibraryException If the patron doesn't have the book to renew or if the patron cannot renew a book not borrowed by them.
     */
    public void renewBook(Book book, LocalDate dueDate) throws LibraryException {
        if (!books.contains(book)) {
            throw new LibraryException("Patron doesn't have this book to renew.");
        }
        if (!book.getLoan().getPatron().equals(this)) {
            throw new LibraryException("Patron cannot renew a book not borrowed by them.");
        }
        book.setDueDate(dueDate);
        book.getLoan().setDueDate(dueDate);
    }

    /**
     * Return a borrowed book.
     *
     * @param book The book to be returned.
     * @throws LibraryException If the patron doesn't have the book to return or if the book's loan is not terminated.
     */
    public void returnBook(Book book) throws LibraryException {
        if (!books.contains(book)) {
            throw new LibraryException("Patron doesn't have this book to return.");
        }
        if (book.getLoan() != null && !book.getLoan().isTerminated()) {
            book.getLoan().terminateLoan(LocalDate.now());
        }
        book.setAvailable(true);
        books.remove(book);
        book.returnToLibrary();
    }

    /**
     * Update the details of the patron.
     *
     * @param name  The new name of the patron (null or empty to keep the existing name).
     * @param phone The new phone number of the patron (null or empty to keep the existing phone number).
     * @param email The new email address of the patron (null or empty to keep the existing email address).
     */
    public void updateDetails(String name, String phone, String email) {
        if (name != null && !name.trim().isEmpty()) {
            this.name = name;
        }
        if (phone != null && !phone.trim().isEmpty()) {
            this.phone = phone;
        }
        if (email != null && !email.trim().isEmpty()) {
            this.email = email;
        }
    }

    /**
     * Check if the patron can borrow more books.
     *
     * @return True if the patron can borrow more books, false otherwise.
     */
    public boolean canBorrow() {
        return books.size() < MAX_BOOKS_ALLOWED;
    }

    /**
     * Add a book to the list of borrowed books for the patron.
     *
     * @param book The book to be added.
     */
    public void addBook(Book book) {
        books.add(book);
    }

    /**
     * Set the unique identifier for the patron.
     *
     * @param id The new unique identifier for the patron.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Get the unique identifier of the patron.
     *
     * @return The unique identifier of the patron.
     */
    public int getId() {
        return id;
    }

    /**
     * Get the name of the patron.
     *
     * @return The name of the patron.
     */
    public String getName() {
        return name;
    }

    /**
     * Get the phone number of the patron.
     *
     * @return The phone number of the patron.
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Get the email address of the patron.
     *
     * @return The email address of the patron.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Check if the patron is marked as deleted.
     *
     * @return True if the patron is marked as deleted, false otherwise.
     */
    public boolean isDeleted() {
        return deleted;
    }

    /**
     * Set the deleted status for the patron.
     *
     * @param deleted True to mark the patron as deleted, false to mark as not deleted.
     */
    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }
    // Check if the patron has borrowed a specific book
    public boolean hasBorrowedBook(Book book) {
        return books.contains(book);
    }

    /**
     * Generate a unique identifier for a new patron.
     *
     * @return The generated unique identifier.
     */
    private static int generateUniqueId() {
        return patronCounter++;
    }

    /**
     * Get a string representation of the Patron object.
     *
     * @return A string representation of the Patron object.
     */
    @Override
    public String toString() {
        return "Patron{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", email='" + email + '\'' +
                ", deleted=" + deleted +
                '}';
    }
}
