package bcu.cmp5332.librarysystem.model;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;


import bcu.cmp5332.librarysystem.data.LoanDataManager;
import bcu.cmp5332.librarysystem.main.LibraryException;

/**
 * The {@code Loan} class represents a loan of a {@link Book} to a {@link Patron} in a library.
 * It contains information such as loan ID, patron, book, start date, due date, termination status,
 * and return date.
 */
public class Loan {

    // Static variable to keep track of the last assigned loan ID
    private static int lastId = 0;

    // Instance variables for loan details
    private int id;
    private Patron patron;
    private Book book;
    private LocalDate startDate;
    private LocalDate dueDate;
    private boolean isTerminated;
    private LocalDate returnDate;

    /**
     * Constructs a new {@code Loan} object with the specified patron, book, start date, and due date.
     *
     * @param patron      The patron to whom the book is loaned.
     * @param book        The book being loaned.
     * @param startDate   The date on which the loan starts.
     * @param dueDate     The due date for returning the book.
     */
    public Loan(Patron patron, Book book, LocalDate startDate, LocalDate dueDate) {
        this.id = ++lastId;
        this.patron = patron;
        this.book = book;
        this.startDate = startDate;
        this.dueDate = dueDate;
        this.isTerminated = false; // Default to false as loan is active initially
        this.returnDate = null; // No return date initially
    }

    // Getters and Setters

    /**
     * Returns the unique ID of the loan.
     *
     * @return The loan ID.
     */
    public int getId() {
        return id;
    }

    /**
     * Returns the patron to whom the book is loaned.
     *
     * @return The patron object.
     */
    public Patron getPatron() {
        return patron;
    }

    /**
     * Returns the book being loaned.
     *
     * @return The book object.
     */
    public Book getBook() {
        return book;
    }

    /**
     * Returns the date on which the loan starts.
     *
     * @return The start date of the loan.
     */
    public LocalDate getStartDate() {
        return startDate;
    }

    /**
     * Returns the due date for returning the book.
     *
     * @return The due date of the loan.
     */
    public LocalDate getDueDate() {
        return dueDate;
    }

    /**
     * Returns the termination status of the loan.
     *
     * @return {@code true} if the loan is terminated, {@code false} otherwise.
     */
    public boolean isTerminated() {
        return isTerminated;
    }

    /**
     * Returns the date on which the book was returned.
     *
     * @return The return date of the book, or {@code null} if not returned.
     */
    public LocalDate getReturnDate() {
        return returnDate;
    }

    /**
     * Sets the patron for the loan.
     *
     * @param patron The patron to set.
     */
    public void setPatron(Patron patron) {
        this.patron = patron;
    }

    /**
     * Sets the book for the loan.
     *
     * @param book The book to set.
     */
    public void setBook(Book book) {
        this.book = book;
    }

    /**
     * Sets the start date of the loan.
     *
     * @param startDate The start date to set.
     */
    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    /**
     * Sets the due date for returning the book.
     *
     * @param dueDate The due date to set.
     */
    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    /**
     * Sets the termination status of the loan.
     *
     * @param isTerminated {@code true} if the loan is terminated, {@code false} otherwise.
     */
    public void setTerminated(boolean isTerminated) {
        this.isTerminated = isTerminated;
    }

    /**
     * Sets the return date of the book and terminates the loan.
     *
     * @param returnDate The date on which the book was returned.
     */
    public void terminateLoan(LocalDate returnDate) {
        this.isTerminated = true;
        this.returnDate = returnDate;
    }

    /**
     * Checks if the loan is overdue.
     *
     * @return {@code true} if the loan is overdue, {@code false} otherwise.
     */
    public boolean isOverdue() {
        LocalDate currentDate = LocalDate.now();
        return !isTerminated && currentDate.isAfter(dueDate);
    }

    /**
     * Stores loan data using the provided {@link Library}.
     *
     * @param library The library to store the loan data in.
     * @throws IOException        If an I/O error occurs while storing the data.
     * @throws LibraryException   If there is an issue with the library.
     */
    public static void storeData(Library library) throws IOException, LibraryException {
        LoanDataManager loanDataManager = new LoanDataManager();
        loanDataManager.storeData(library);
    }

    /**
     * Creates a {@code Loan} object from the given data string and adds it to the provided {@link Library}.
     *
     * @param line    The data string representing the loan.
     * @param library The library to add the loan to.
     * @return The created loan object.
     * @throws LibraryException If there is an issue with the library.
     */
    public static Loan createLoanFromData(String line, Library library) throws LibraryException {
        try {
            String[] parts = line.split(",");
            int id = Integer.parseInt(parts[0]);
            int patronId = Integer.parseInt(parts[1]);
            int bookId = Integer.parseInt(parts[2]);
            LocalDate startDate = LocalDate.parse(parts[3]);
            LocalDate dueDate = LocalDate.parse(parts[4]);
            boolean isTerminated = Boolean.parseBoolean(parts[5]);
            LocalDate returnDate = (parts[6].isEmpty() ? null : LocalDate.parse(parts[6]));

            Book book = library.getBookByID(bookId);
            Patron patron = library.getPatronByID(patronId);

            Loan loan = new Loan(patron, book, startDate, dueDate);
            loan.id = id;
            loan.isTerminated = isTerminated;
            loan.returnDate = returnDate;

            return loan;
        } catch (NumberFormatException | DateTimeParseException e) {
            throw new LibraryException("Error parsing loan data: " + e.getMessage());
        }
    }
    

	public void setId(int id2) {		
	}
}