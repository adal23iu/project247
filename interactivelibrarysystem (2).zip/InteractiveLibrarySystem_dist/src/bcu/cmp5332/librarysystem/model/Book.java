
package bcu.cmp5332.librarysystem.model;

import bcu.cmp5332.librarysystem.data.BookDataManager;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.io.IOException;
import java.time.LocalDate;

/**
 * Represents a book in the library.
 */
public class Book {

    /**
     * The unique identifier of the book.
     */
    private int id;

    /**
     * The title of the book.
     */
    private String title;

    /**
     * The author of the book.
     */
    private String author;

    /**
     * The publication year of the book.
     */
    private String publicationYear;

    /**
     * The publisher of the book.
     */
    private String publisher; // New property for publisher

    /**
     * Indicates whether the book has been soft-deleted or hidden.
     */
    private boolean deleted; // Property to soft delete/hide the book

    /**
     * Indicates whether the book is available for borrowing.
     */
    private boolean available; // Property to indicate book availability

    /**
     * The loan associated with the book.
     */
    private Loan loan;

    /**
     * Constructs a new Book object with the specified details.
     *
     * @param id              The unique identifier of the book.
     * @param title           The title of the book.
     * @param author          The author of the book.
     * @param publicationYear The publication year of the book.
     * @param publisher       The publisher of the book.
     * @param deleted         Indicates whether the book is initially deleted.
     * @param available       Indicates whether the book is initially available.
     */
    public Book(int id, String title, String author, String publicationYear, String publisher, boolean deleted, boolean available) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
        this.publisher = publisher;
        this.deleted = false; // Initially, the book is not deleted
        this.available = true; // Initially, the book is available
    }

    /**
     * Retrieves the unique identifier of the book.
     *
     * @return The unique identifier of the book.
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the unique identifier of the book.
     *
     * @param id The unique identifier to set.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Retrieves the title of the book.
     *
     * @return The title of the book.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the title of the book.
     *
     * @param title The title to set.
     */
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getAuthor() {
        return author;
    }
    
    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublicationYear() {
        return publicationYear;
    }

    public void setPublicationYear(String publicationYear) {
        this.publicationYear = publicationYear;
    }
    
    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
    
    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }
	
    public String getDetailsShort() {
        if (!isDeleted()) {
            return String.format("Book #%d - %s by %s (%s)", id, title, author, getStatus());
        } else {
            return String.format("Book #%d - [DELETED]", id);
        }
    }
    
    public void borrowBook(Patron patron, LocalDate dueDate) throws LibraryException {
        if (!isAvailable()) {
            throw new LibraryException("Book is not available for borrowing.");
        }
        if (!patron.canBorrow()) {
            throw new LibraryException("Patron has reached the maximum borrowing limit.");
        }
        setDueDate(dueDate);
        // Update to create a new Loan object
        this.loan = new Loan(patron, this, LocalDate.now(), dueDate);
        setAvailable(false); // Update book availability
    }

   public void renewBook(Patron patron, LocalDate dueDate) throws LibraryException {
     if (!isOnLoan()) {
         throw new LibraryException("Book is not on loan.");
     }
     if (!getLoan().getPatron().equals(patron)) {
         throw new LibraryException("Patron cannot renew a book not borrowed by them.");
     }
     setDueDate(dueDate);
     getLoan().setDueDate(dueDate);
 }

    // Method to get detailed information about the book
    public String getDetailsLong() {
        StringBuilder details = new StringBuilder();
        details.append("Book Details:\n");
        details.append("ID: ").append(id).append("\n");
        details.append("Title: ").append(title).append("\n");
        details.append("Author: ").append(author).append("\n");
        details.append("Publication Year: ").append(publicationYear).append("\n");
        details.append("Publisher: ").append(publisher).append("\n");
        
        if (isOnLoan()) {
            details.append("Status: On Loan\n");
            details.append("Due Date: ").append(getDueDate()).append("\n");
            details.append("Loaned to: ").append(loan.getPatron().getName()).append("\n");
        } else {
            details.append("Status: Available\n");
        }
        
        return details.toString();
    }
    
    // Method to check if the book is on loan
    public boolean isOnLoan() {
        return (loan != null);
    }
    
    // Method to get status of the book
    public String getStatus() {
        return isOnLoan() ? "On Loan" : "Available";
    }

    // Method to get due date of the book if on loan
    public LocalDate getDueDate() {
        if (loan != null) {
            return loan.getDueDate();
        }
        return null;
    }
    
    // Method to set due date for the book
    public void setDueDate(LocalDate dueDate) throws LibraryException {
        if (loan != null) {
            loan.setDueDate(dueDate);
        } else {
            throw new LibraryException("Book is not on loan, cannot set due date.");
        }
    }

    // Method to get loan associated with the book
    public Loan getLoan() {
        return loan;
    }

    // Method to set loan for the book
    public void setLoan(Loan loan) {
        this.loan = loan;
    }

 // Method to return the book to the library
    public void returnToLibrary() {
        if (isOnLoan()) {
            try {
                getLoan().getPatron().returnBook(this);
                this.loan = null; // Remove loan reference
                setAvailable(true); // Update book availability
            } catch (LibraryException e) {
                System.out.println("Error returning the book: " + e.getMessage());
            }
        }
    }
    
    // Method to soft delete/hide the book
     public void deleteBook() {
        this.deleted = true;
        // If book is on loan, return it before deleting
        if (isOnLoan()) {
            returnToLibrary();
        }
    }
     
     public static void storeData(Library library) throws IOException, LibraryException {
         BookDataManager bookDataManager = new BookDataManager();
         bookDataManager.storeData(library);
     }
    
 // Method to set availability of the book
    public void setAvailable(boolean available) {
        // Update the availability status of the book
        this.available = available;
    }

    // Method to check if the book is available
    public boolean isAvailable() {
        return available;
    }
}
