
package bcu.cmp5332.librarysystem.model;

import bcu.cmp5332.librarysystem.data.PatronDataManager;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.io.IOException;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * The {@code Library} class represents a library system with functionality
 * for managing patrons, books, and loans.
 */
public class Library {

    /**
     * The default loan period in days for borrowed books.
     */
    private final int loanPeriod = 7;

    /**
     * A map that stores patrons using their unique IDs as keys.
     */
    private final Map<Integer, Patron> patrons = new HashMap<>();

    /**
     * A map that stores books using their unique IDs as keys. The books are sorted by ID.
     */
    private final Map<Integer, Book> books = new TreeMap<>();

    /**
     * A list that stores active loans in the library.
     */
    private final List<Loan> loans = new ArrayList<>();

    /**
     * The maximum number of patrons allowed in the library.
     */
    private static final int MAX_PATRONS = 50;

    /**
     * The data manager responsible for handling patron data.
     */
    private final PatronDataManager patronDataManager;

    /**
     * Creates a new {@code Library} instance, initializing the {@code PatronDataManager} and loading data.
     *
     * @throws IOException        If an I/O error occurs.
     * @throws LibraryException   If there is an issue with library operations.
     */
    public Library() throws IOException, LibraryException {
        this.patronDataManager = new PatronDataManager();
        patronDataManager.loadData(this);
    }

    public int getLoanPeriod() {
        return loanPeriod;
    }

    public int getMaxPatrons() {
        return MAX_PATRONS;
    }

    public int getMaxPatronId() {
        int maxId = 0;
        for (Patron patron : patrons.values()) {
            if (patron.getId() > maxId) {
                maxId = patron.getId();
            }
        }
        return maxId;
    }

    public List<Book> getBooks() {
        List<Book> out = new ArrayList<>();
        for (Book book : books.values()) {
            if (!book.isDeleted()) {
                out.add(book);
            }
        }
        return Collections.unmodifiableList(out);
    }

    public List<Book> getAvailableBooks() {
        List<Book> availableBooks = new ArrayList<>();
        for (Book book : books.values()) {
            if (!book.isDeleted() && book.isAvailable()) {
                availableBooks.add(book);
            }
        }
        return Collections.unmodifiableList(availableBooks);
    }

    public List<Patron> getActivePatrons() {
        List<Patron> activePatrons = new ArrayList<>();
        for (Patron patron : patrons.values()) {
            if (!patron.isDeleted()) {
                activePatrons.add(patron);
            }
        }
        return Collections.unmodifiableList(activePatrons);
    }

    public List<Loan> getActiveLoans() {
        List<Loan> activeLoans = new ArrayList<>();
        for (Loan loan : loans) {
            if (!loan.isTerminated()) {
                activeLoans.add(loan);
            }
        }
        return Collections.unmodifiableList(activeLoans);
    }

    public Book getBookByID(int id) throws LibraryException {
        if (!books.containsKey(id)) {
            throw new LibraryException("There is no such book with that ID.");
        }
        Book book = books.get(id);
        if (book.isDeleted()) {
            throw new LibraryException("The book with ID " + id + " has been deleted.");
        }
        return book;
    }

    public void borrowBook(int patronId, int bookId, LocalDate dueDate) throws LibraryException {
        Patron patron = getPatronByID(patronId);
        Book book = getBookByID(bookId);

        try {
            // Check if the book is not on loan or available
            if (book.getLoan() == null || book.isAvailable()) {
                // If the book was on loan, remove it from the previous patron's list of borrowed books
                if (book.getLoan() != null) {
                    Patron previousPatron = book.getLoan().getPatron();
                    previousPatron.returnBook(book);
                }

                // Create a new Loan object
                Loan loan = new Loan(patron, book, LocalDate.now(), dueDate);

                // Add the loan to the list of active loans
                addLoan(loan);

                // Update book information
                book.setLoan(loan);

                // Add the book to the current patron's list of borrowed books
                patron.borrowBook(book, dueDate);

                System.out.println("Book with ID " + bookId + " successfully borrowed.");
            } else {
                throw new LibraryException("The book with ID " + bookId + " is not available for borrowing.");
            }
        } catch (LibraryException e) {
            throw new LibraryException("Failed to borrow the book: " + e.getMessage());
        }
    }

    public void issueBook(int bookId, int patronId) throws LibraryException {
        Book book = getBookByID(bookId);
        Patron patron = getPatronByID(patronId);

        if (!book.isAvailable()) {
            throw new LibraryException("The book with ID " + bookId + " is not available for issuing.");
        }

        if (!patron.canBorrow()) {
            throw new LibraryException("Patron has reached the maximum number of borrowed books.");
        }

        try {
            // Check if the book is already on loan
            if (book.getLoan() != null) {
                throw new LibraryException("The book with ID " + bookId + " is already on loan.");
            }

            // Create a new Loan object
            Loan loan = new Loan(patron, book, LocalDate.now(), LocalDate.now().plusDays(getLoanPeriod()));

            // Set the due date for the loan
            loan.setDueDate(LocalDate.now().plusDays(getLoanPeriod()));

            // Add the loan to the list of active loans
            addLoan(loan);

            // Update book information
            book.setLoan(loan);
        } catch (LibraryException e) {
            throw new LibraryException("Error issuing the book: " + e.getMessage());
        }
    }

    public void returnBook(int bookId, int patronId, LocalDate returnDate) throws LibraryException {
        Book book = getBookByID(bookId);

        // Check if the book is not available (on loan) and has a valid loan associated with it
        if (!book.isAvailable() && book.getLoan() != null) {
            Loan loan = book.getLoan();

            // Check if the loan is terminated
            if (!loan.isTerminated()) {
                loan.terminateLoan(returnDate);
            } else {
                throw new LibraryException("The loan for the book with ID " + bookId + " has already been terminated.");
            }

            // Set the book as available
            book.setAvailable(true);

            // Remove the loan from the list of active loans
            removeLoan(loan.getId());

            // Clear the loan association from the book
            book.setLoan(null);

            System.out.println("Book with ID " + bookId + " successfully returned.");
        } else {
            throw new LibraryException("The book with ID " + bookId + " is not currently on loan.");
        }
    }

    public void removeBook(int bookId) throws LibraryException {
        if (!books.containsKey(bookId)) {
            throw new LibraryException("There is no such book with that ID.");
        }
        Book bookToRemove = books.get(bookId);
        if (!bookToRemove.isAvailable()) {
            throw new LibraryException("The book with ID " + bookId + " is currently on loan and cannot be removed.");
        }
        bookToRemove.setDeleted(true);
        bookToRemove.setLoan(null);
        try {
            storeData();
        } catch (IOException e) {
            System.out.println("Error storing data: " + e.getMessage());
        }
    }

    public void addBook(Book book) {
        try {
            if (books.containsKey(book.getId())) {
                // Update the existing book with new information
                Book existingBook = books.get(book.getId());
                existingBook.setTitle(book.getTitle());
                existingBook.setAuthor(book.getAuthor());
                existingBook.setPublicationYear(book.getPublicationYear());
                existingBook.setPublisher(book.getPublisher());
                existingBook.setDeleted(book.isDeleted());
                existingBook.setAvailable(book.isAvailable());
            } else {
                // Add the new book
                books.put(book.getId(), book);
            }

            // Store data after the book is added or updated
            storeData();
        } catch (IOException e) {
            System.out.println("Error storing data: " + e.getMessage());
        } catch (LibraryException le) {
            System.out.println("LibraryException: " + le.getMessage());
            // Handle the exception or log it appropriately
        }
    }


    public void renewBook(int patronId, int bookId, LocalDate currentDate) throws LibraryException {
        Book book = getBookByID(bookId);
        Patron patron = getPatronByID(patronId);

        if (book.isAvailable() || book.getLoan() == null) {
            throw new LibraryException("The book with ID " + bookId + " is not currently on loan and cannot be renewed.");
        }

        Loan loan = book.getLoan();

        if (!loan.getPatron().equals(patron)) {
            throw new LibraryException("The book with ID " + bookId + " is not borrowed by the specified patron.");
        }

        if (loan.isTerminated()) {
            throw new LibraryException("The loan for the book with ID " + bookId + " has already been terminated.");
        }

        LocalDate dueDate = loan.getDueDate();

        // Check if the book can be renewed (e.g., within the renewal period)
        if (currentDate.isAfter(dueDate)) {
            throw new LibraryException("The book with ID " + bookId + " cannot be renewed after the due date.");
        }

        loan.setDueDate(dueDate.plusDays(getLoanPeriod()));

        System.out.println("Book with ID " + bookId + " renewed for patron with ID " + patronId +
                ". New due date: " + loan.getDueDate());
        try {
            storeData();
        } catch (IOException e) {
            System.out.println("Error storing data: " + e.getMessage());
        }
    }

    public void showBookDetails(int bookId) throws LibraryException {
        Book book = getBookByID(bookId);
        System.out.println("Book details:\n" + book.toString());
    }

    public List<Loan> getAllLoans() {
        return Collections.unmodifiableList(loans);
    }

    public void addLoan(Loan loan) throws LibraryException {
        loans.add(loan);
        try {
            storeData();
        } catch (IOException e) {
            throw new LibraryException("Error storing data: " + e.getMessage(), e);
        }
    }

    public void removeLoan(int loanId) throws LibraryException {
        loans.removeIf(loan -> loan.getId() == loanId);
        try {
            storeData();
        } catch (IOException e) {
            throw new LibraryException("Error storing data: " + e.getMessage(), e);
        }
    }


    public Patron getPatronByID(int patronID) throws LibraryException {
        Patron patron = patrons.get(patronID);
        if (patron == null) {
            throw new LibraryException("Patron with ID " + patronID + " not found in the library.");
        }
        return patron;
    }

    public int generateUniqueId() {
        int newId = patrons.size() + 1;
        // Ensure the generated ID is unique
        while (patrons.containsKey(newId)) {
            newId++;
        }
        return newId;
    }
    
    public void storeData() throws IOException, LibraryException {
        patronDataManager.storeData(this);
    }

    public void updatePatron(Patron updatedPatron) throws LibraryException {
        try {
            patronDataManager.updatePatron(this, updatedPatron);
            storeData();
        } catch (Exception e) {
            System.out.println("Error updating patron: " + e.getMessage());
        }
    }

    public void deletePatron(int patronId) throws LibraryException {
        Patron patron = getPatronByID(patronId);
        if (patron != null) {
            patrons.remove(patronId);
            System.out.println("Patron with ID " + patronId + " deleted successfully.");
            try {
                storeData();
            } catch (IOException e) {
                System.out.println("Error storing data: " + e.getMessage());
            }
        } else {
            throw new LibraryException("Patron with ID " + patronId + " not found in the library.");
        }
    }

    public void showPatronDetails(int patronId) throws LibraryException {
        Patron patron = getPatronByID(patronId);

        if (patron == null) {
            throw new LibraryException("Patron not found with ID: " + patronId);
        }

        System.out.println("Patron ID: " + patron.getId());
        System.out.println("Name: " + patron.getName());
        System.out.println("Phone: " + patron.getPhone());
        System.out.println("Email: " + patron.getEmail());
        System.out.println("Deleted: " + patron.isDeleted());
        System.out.println("---------------");
    }

    public Patron getPatronByNameAndPhone(String name, String phone) {
        for (Patron patron : patrons.values()) {
            if (patron.getName().equalsIgnoreCase(name) && patron.getPhone().equalsIgnoreCase(phone)) {
                return patron;
            }
        }
        return null;
    }

    public List<Loan> getLoanHistory(int patronId) throws LibraryException {
        Patron patron = getPatronByID(patronId);
        List<Loan> patronLoans = new ArrayList<>();

        for (Loan loan : loans) {
            if (loan.getPatron().equals(patron)) {
                patronLoans.add(loan);
            }
        }

        return Collections.unmodifiableList(patronLoans);
    }

    public Map<Integer, Patron> getPatrons() {
        return patrons;
    }

    public void addPatron(Patron patron) throws LibraryException {
        patron.setId(generateUniqueId());
        addPatronObject(patron);
        try {
            storeData();
        } catch (IOException e) {
            System.out.println("Error storing data: " + e.getMessage());
        }
    }

    public void addPatronObject(Patron patron) throws LibraryException {
        patrons.put(patron.getId(), patron);
        System.out.println("Patron added successfully with ID: " + patron.getId());
        // Do not call patronDataManager.addPatron here
    }


    public void listPatrons() {
        for (Map.Entry<Integer, Patron> entry : patrons.entrySet()) {
            Patron patron = entry.getValue();
            System.out.println("ID: " + patron.getId() + ", Name: " + patron.getName() + ", Phone: " + patron.getPhone() + ", Email: " + patron.getEmail());
        }
    }
    
    public List<Patron> getAllPatrons() {
        return patrons.values().stream()
                .filter(patron -> !patron.isDeleted())
                .collect(Collectors.toList());
    }

    public int getMaxBookId() {
        int maxId = 0;
        for (Book book : books.values()) {
            if (book.getId() > maxId) {
                maxId = book.getId();
            }
        }
        return maxId;
    }

    public List<Loan> getLoans() {
        return loans;
    }    
}

 